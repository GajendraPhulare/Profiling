package SpringProfiling.Profiling;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
public class AppConfig {
	
	@Bean
	@Profile("old")
  CompactDisc hindiOldCompactDisc() {
		
		return new OldHindiSongCD();
	}
	
	@Bean
	@Profile("new")
	  CompactDisc latestHindiCompactDisc() {
			
			return new LatestHindiSongCD();
		}
	
	@Bean
	@Profile("new")
	CDPlayer cdnewPlayer() {
		
		return new SonyCDPlayer(latestHindiCompactDisc());
	}
	
	@Bean
	@Profile("old")
	CDPlayer cdOldPlayer() {
		
		return new SonyCDPlayer(hindiOldCompactDisc());
	}

	

}
