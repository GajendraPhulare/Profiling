package SpringProfiling.Profiling;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.env.AbstractEnvironment;


public class App 
{
    public static void main( String[] args )
    {
    	 System.setProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME, "new");
    	ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
    	CDPlayer player=context.getBean(SonyCDPlayer.class);
    	player.startPlayer();
    	
    	 System.setProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME, "old");
    	 context = new AnnotationConfigApplicationContext(AppConfig.class);
          player=context.getBean(SonyCDPlayer.class);
     	player.startPlayer();
    	
    	 
  	  
  	
  	
    }
}
