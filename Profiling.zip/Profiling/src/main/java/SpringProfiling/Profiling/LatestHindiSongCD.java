package SpringProfiling.Profiling;

public class LatestHindiSongCD implements CompactDisc {

	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing latest bollywood hits....");

	}

}
