package SpringProfiling.Profiling;

public class SonyCDPlayer implements CDPlayer {

	private CompactDisc cd;
	
	SonyCDPlayer(){
		
	}
	
SonyCDPlayer(CompactDisc cd){
		this.cd=cd;
	}
	public void startPlayer() {
		System.out.println("Player started....");
this.cd.play();
	}

}
