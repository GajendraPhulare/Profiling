package SpringProfiling.Profiling;

public interface CompactDisc {
	
	void play();

}
