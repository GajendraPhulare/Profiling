package SpringProfiling.Profiling;

public class OldHindiSongCD implements CompactDisc {

	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Player Hindi old songs ....");
	}

}
