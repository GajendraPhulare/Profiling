package SpringProfiling.Profiling;

public interface CDPlayer {
 void startPlayer();
}
